# Messenger — веб и мобильное приложение

## Запуск на компьютере
1. `python -m pip install -r requirements.txt`
2. `python app.py` (или `start.bat`), открыть http://127.0.0.1:5001

## Что поменялось
- `templates/login.html`, `templates/messenger.html` — новый адаптивный интерфейс (компьютер и телефон).
- `app.py` — исправления сервера (см. ниже) + новые адреса `/api/ice`, `/api/chat/<id>/read`, событие `typing`, `/manifest.webmanifest`, `/sw.js`.
- `static/` — иконки, манифест PWA, service worker.
- Старые шаблоны сохраните в копию перед заменой.

## Настройки (переменные среды, все необязательные)
| Переменная | Что делает |
|---|---|
| `PORT` | порт (по умолчанию 5001) |
| `SECRET_KEY` | ключ сессий (иначе создаётся файл `.secret_key`) |
| `INVITE_CODE` | если задан, регистрация только по этому коду |
| `SEED_DEMO` | `1` создать демо-пользователей (по умолчанию только на пустой базе) |
| `COOKIE_SECURE` | `1` — cookie только по HTTPS (включайте, когда сервер открыт по https) |
| `TURN_URL`, `TURN_USER`, `TURN_PASS` | TURN-сервер для звонков между разными сетями |
| `CORS_ORIGINS` | ограничить Origin для сокетов (по умолчанию любой) |
| `USE_WAITRESS` | `1` — запуск через waitress (без WebSocket) |

## Телефон
- Быстро: открыть адрес в Chrome на телефоне → меню → «Добавить на главный экран» (PWA).
- APK: см. `apk/capacitor.config.json` и инструкцию в чате (Capacitor + Android Studio).
